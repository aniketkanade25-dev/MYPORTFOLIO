console.log("MAIN JS LOADED");


// =========================
// SKILLS ACCORDION
// =========================

const skillHeaders = document.querySelectorAll(".skill-header");

skillHeaders.forEach(function (header) {

    header.addEventListener("click", function () {

        const currentSkill = header.parentElement;

        document.querySelectorAll(".skill-item").forEach(function (item) {

            if (item !== currentSkill) {
                item.classList.remove("active");
            }

        });

        currentSkill.classList.toggle("active");

    });

});


// =========================
// MOBILE MENU
// =========================

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.querySelector(".nav-links");

if (menuToggle && navLinks) {

    menuToggle.addEventListener("click", function () {

        navLinks.classList.toggle("active");
        menuToggle.classList.toggle("active");

    });

    navLinks.querySelectorAll("a").forEach(function (link) {

        link.addEventListener("click", function () {

            navLinks.classList.remove("active");
            menuToggle.classList.remove("active");

        });

    });

}


// =========================
// SCROLL ANIMATIONS
// =========================

const animatedElements = document.querySelectorAll(
    ".animate-on-scroll, .section-header, .project-card, .about-content, .skills-list"
);

animatedElements.forEach(function (element) {
    element.classList.add("animate-on-scroll");
});


const observer = new IntersectionObserver(function (entries) {

    entries.forEach(function (entry) {

        if (entry.isIntersecting) {

            entry.target.classList.add("show");

        }

    });

}, {
    threshold: 0.15
});


document.querySelectorAll(".animate-on-scroll").forEach(function (element) {

    observer.observe(element);

});
/* =========================
   LANDING → HERO
========================= */

const exploreBtn = document.getElementById("exploreBtn");
const landingScreen = document.getElementById("landing");

if (exploreBtn && landingScreen) {

    exploreBtn.addEventListener("click", function () {

        landingScreen.classList.add("exit");

        setTimeout(function () {
            landingScreen.style.display = "none";
        }, 1000);

    });
}
const contactForm = document.getElementById("contactForm");

if (contactForm) {
    contactForm.addEventListener("submit", async function (e) {
        e.preventDefault();

        const submitButton = contactForm.querySelector("button[type='submit']");

        submitButton.disabled = true;
        submitButton.textContent = "SENDING...";

        const formData = new FormData(contactForm);

        try {
            const response = await fetch("/", {
                method: "POST",
                body: formData,
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                }
            });

            const data = await response.json();

            if (data.success) {

                // Reset form
                contactForm.reset();

                // Show success message
                let successMessage = document.getElementById("contactSuccess");

                if (!successMessage) {
                    successMessage = document.createElement("p");
                    successMessage.id = "contactSuccess";
                    successMessage.className = "contact-success";

                    contactForm.appendChild(successMessage);
                }

                successMessage.textContent = data.message;

            } else {
                alert("Something went wrong. Please try again.");
            }

        } catch (error) {
            console.error(error);
            alert("Unable to send message. Please try again.");
        }

        submitButton.disabled = false;
        submitButton.textContent = "SEND MESSAGE";
    });
}