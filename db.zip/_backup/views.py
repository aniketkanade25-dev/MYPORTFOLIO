from django.shortcuts import render, redirect
from django.contrib import messages
from django.conf import settings
from django.utils.html import escape
from django.http import JsonResponse

from brevo import Brevo
from brevo.transactional_emails import (
    SendTransacEmailRequestSender,
    SendTransacEmailRequestToItem,
    SendTransacEmailRequestReplyTo,
)

from .models import Project, ContactMessage


def home(request):
    projects = Project.objects.all()

    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        email = request.POST.get("email", "").strip()
        subject = request.POST.get("subject", "").strip()
        message = request.POST.get("message", "").strip()

        # Save enquiry to database
        ContactMessage.objects.create(
            name=name,
            email=email,
            subject=subject,
            message=message
        )

        # Brevo client
        client = Brevo(api_key=settings.BREVO_API_KEY)

        # Send email to Aniket
        client.transactional_emails.send_transac_email(
            subject=f"New Portfolio Enquiry: {subject}",
            html_content=f"""
                <html>
                <body>
                    <h2>New Portfolio Enquiry</h2>

                    <p><strong>Name:</strong> {escape(name)}</p>
                    <p><strong>Email:</strong> {escape(email)}</p>
                    <p><strong>Subject:</strong> {escape(subject)}</p>

                    <h3>Message</h3>
                    <p>{escape(message).replace(chr(10), "<br>")}</p>
                </body>
                </html>
            """,
            sender=SendTransacEmailRequestSender(
                name="Aniket Kanade",
                email="aniketkanade2121@gmail.com",
            ),
            to=[
                SendTransacEmailRequestToItem(
                    email="aniketkanade2121@gmail.com",
                    name="Aniket Kanade",
                )
            ],
            reply_to=SendTransacEmailRequestReplyTo(
                email=email,
                name=name,
            ),
        )

        # Automatic reply to visitor
        client.transactional_emails.send_transac_email(
            subject="Thanks for contacting Aniket Kanade",
            html_content=f"""
                <html>
                <body>
                    <h2>Thank you, {escape(name)}!</h2>

                    <p>
                        Thanks for contacting me through my portfolio.
                    </p>

                    <p>
                        I have received your message and will get back
                        to you as soon as possible.
                    </p>

                    <p>
                        Best regards,<br>
                        <strong>Aniket Kanade</strong>
                    </p>
                </body>
                </html>
            """,
            sender=SendTransacEmailRequestSender(
                name="Aniket Kanade",
                email="aniket.kanade25@mmit.edu.in",
            ),
            to=[
                SendTransacEmailRequestToItem(
                    email=email,
                    name=name,
                )
            ],
        )

        return JsonResponse({
    "success": True,
    "message": "Your message has been sent successfully!"
})

    return render(request, "home.html", {"projects": projects})