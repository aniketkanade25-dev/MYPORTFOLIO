document.addEventListener("DOMContentLoaded", () => {
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const landingScreen = document.getElementById("landing");
    const exploreButton = document.getElementById("exploreBtn");
    const menuToggle = document.getElementById("menuToggle");
    const navLinks = document.getElementById("navLinks");

    if (landingScreen && exploreButton) {
        exploreButton.addEventListener("click", () => {
            landingScreen.classList.add("exit");
            window.setTimeout(() => {
                landingScreen.hidden = true;
                document.querySelector(".hero-buttons a")?.focus({ preventScroll: true });
            }, prefersReducedMotion ? 0 : 820);
        });
    }

    function setMenuOpen(isOpen, restoreFocus = false) {
        if (!menuToggle || !navLinks) {
            return;
        }

        navLinks.classList.toggle("active", isOpen);
        menuToggle.classList.toggle("active", isOpen);
        menuToggle.setAttribute("aria-expanded", String(isOpen));
        menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");

        if (isOpen) {
            navLinks.querySelector("a")?.focus();
        } else if (restoreFocus) {
            menuToggle.focus();
        }
    }

    if (menuToggle && navLinks) {
        menuToggle.addEventListener("click", () => {
            setMenuOpen(menuToggle.getAttribute("aria-expanded") !== "true");
        });

        document.addEventListener("keydown", (event) => {
            if (event.key === "Escape" && menuToggle.getAttribute("aria-expanded") === "true") {
                setMenuOpen(false, true);
            }
        });

        window.addEventListener("resize", () => {
            if (window.innerWidth > 760 && menuToggle.getAttribute("aria-expanded") === "true") {
                setMenuOpen(false);
            }
        });
    }

    document.addEventListener("click", (event) => {
        if (!(event.target instanceof Element)) {
            return;
        }

        const link = event.target.closest('a[href^="#"]');
        if (!link) {
            return;
        }

        const target = document.getElementById(link.hash.slice(1));
        if (!target) {
            return;
        }

        event.preventDefault();

        if (navLinks?.contains(link)) {
            setMenuOpen(false);
        }

        target.setAttribute("tabindex", "-1");
        target.focus({ preventScroll: true });
        target.scrollIntoView({ behavior: prefersReducedMotion ? "auto" : "smooth" });
        window.history.replaceState(null, "", link.hash);
    });

    const skillButtons = document.querySelectorAll(".skill-header[aria-controls]");
    skillButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const isOpen = button.getAttribute("aria-expanded") !== "true";

            skillButtons.forEach((otherButton) => {
                const otherPanel = document.getElementById(otherButton.getAttribute("aria-controls"));
                const otherItem = otherButton.closest(".skill-item");
                const shouldClose = otherButton !== button || !isOpen;

                otherButton.setAttribute("aria-expanded", String(!shouldClose));
                otherItem?.classList.toggle("active", !shouldClose);
                if (otherPanel) {
                    otherPanel.hidden = shouldClose;
                }
            });
        });
    });

    const revealTargets = new Set(document.querySelectorAll(
        ".animate-on-scroll, .section-header, .project-card, .about-content, .skills-list"
    ));
    revealTargets.forEach((element) => element.classList.add("animate-on-scroll"));

    if (prefersReducedMotion || !("IntersectionObserver" in window)) {
        revealTargets.forEach((element) => element.classList.add("is-visible"));
    } else {
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add("is-visible");
                    entry.target.classList.remove("reveal-pending");
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });

        revealTargets.forEach((element) => {
            const bounds = element.getBoundingClientRect();
            const isInView = bounds.top < window.innerHeight && bounds.bottom > 0;

            if (isInView) {
                element.classList.add("is-visible");
            } else {
                element.classList.add("reveal-pending");
                revealObserver.observe(element);
            }
        });
    }

    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        let isSubmitting = false;
        const submitButton = contactForm.querySelector("button[type='submit']");
        const submitLabel = submitButton?.querySelector(".submit-label");
        const statusMessage = document.getElementById("contactStatus");

        contactForm.addEventListener("submit", async (event) => {
            event.preventDefault();
            if (isSubmitting || !contactForm.reportValidity()) {
                return;
            }

            isSubmitting = true;
            if (submitButton) {
                submitButton.disabled = true;
            }
            if (submitLabel) {
                submitLabel.textContent = "SENDING...";
            }
            contactForm.setAttribute("aria-busy", "true");
            statusMessage?.classList.remove("is-error");
            if (statusMessage) {
                statusMessage.textContent = "";
            }

            try {
                const response = await fetch(contactForm.action, {
                    method: contactForm.method.toUpperCase(),
                    body: new FormData(contactForm),
                    headers: {
                        "X-Requested-With": "XMLHttpRequest",
                        "Accept": "application/json",
                    },
                });
                const result = await response.json().catch(() => null);

                if (!response.ok || !result || typeof result.success !== "boolean") {
                    if (statusMessage) {
                        statusMessage.textContent = result?.message || "Your message could not be processed. Please try again.";
                        statusMessage.classList.add("is-error");
                    }
                    return;
                }

                if (statusMessage) {
                    statusMessage.textContent = result.message;
                    statusMessage.classList.toggle("is-error", !result.success);
                }
                if (result.success) {
                    contactForm.reset();
                }
            } catch {
                if (statusMessage) {
                    statusMessage.textContent = "Unable to send your message right now. Please try again.";
                    statusMessage.classList.add("is-error");
                }
            } finally {
                isSubmitting = false;
                if (submitButton) {
                    submitButton.disabled = false;
                }
                if (submitLabel) {
                    submitLabel.textContent = "SEND MESSAGE";
                }
                contactForm.removeAttribute("aria-busy");
            }
        });
    }
});
